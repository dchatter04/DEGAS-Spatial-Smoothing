# In vscode, open a terminal, and type the following bash commands:

# srun -p gpu-debug -A r00257 --time=01:00:00 --gpus-per-node v100:1 --mem 100G --pty bash
# srun -p gpu -A r00257 --time=02:00:00 --gpus-per-node v100:1 --mem 50G --pty bash
# srun -p general -A r00257 --time=02:00:00 --mem 50G --pty bash
# srun -p gpu -A r00257 --time=02:00:00 -gpus-per-node v100:1 --mem 100G --pty bash

# module load r/4.4.1
# module load python/gpu/3.10.10
# R


library(devtools)
library(withr)
library(rprojroot)
library(tidyverse)
library(magrittr)
library(here)
# If DEGAS hasn't been installed, do so using this command (after creating a r-packages file in your root directory)
#with_libpaths(new = '~/r-packages', install_github("tsteelejohnson91/DEGAS"))
library(DEGAS)
library(DEGAS, lib.loc = "/N/project/degas_st/DEGAS_package")
.libPaths(c("/N/project/degas_st/DEGAS_package", .libPaths()))
set.seed(2)

meta_data_columns <- c("V1", "cell_id", "slide_ID_numeric", "Run_Tissue_name", "x_FOV_px", "y_FOV_px", "x_FOV_px" , "y_FOV_px", "qcFlagsFOV", "cellType", "niche")

# What is the name of this experiment/sample?
sample_name <- "lihc_allgenes_seuratobj"

# Patient data


## Clinical outcomes
Ypat <- data.table::fread('/N/project/degas_st/cosmyx/data/Reference_liver/patLab.csv', sep = ",")
#Ypat = Ypat[colnames(Xpat),]
rownames(Ypat) = Ypat$PATIENT_ID

library(dplyr)
dim(Xpat)
dim(Ypat)
common_ids <- intersect(Xpat$PATIENT_ID, Ypat$PATIENT_ID)
length(common_ids)
Xpat_unique <- Xpat %>%
  filter(PATIENT_ID %in% common_ids) %>%
  distinct(PATIENT_ID, .keep_all = TRUE)

dim(Xpat_unique)  # should be 369 x ..


## RNA-seq
Xpat <- data.table::fread('/N/project/degas_st/cosmyx/data/TCGA/patDat.csv', sep = ",") # Tumor and normal tissue
#Xpat_t <- as.data.frame(t(Xpat))
Xpat_t <- as.data.frame(t(Xpat_unique))
colnames(Xpat_t) = Xpat_t[1,]
Xpat_t <- Xpat_t[-1,]
Xpat_t$genes <- rownames(Xpat_t)
Xpat_t <- Xpat_t[,c(dim(Xpat_t)[2],1:(dim(Xpat_t)[2]-1))]
Xpat_t[1:5,1:5]
dim(Xpat_t)


lihc_metadat = read_csv('/N/project/degas_st/CosMx_liver_data/cosmx_liver_metadata.csv') 
#head(lihc_metadat)
lihc_metadat$...1
names(lihc_metadat)[names(lihc_metadat) == "...1"]         <- "cell_id"
head(lihc_metadat)

# Loading Xenium data
#lihc_dat = readRDS("/N/project/degas_st/CosMx_liver_data/LiverDataReleaseSeurat_newUMAP.RDS")

#lihc = lihc_dat@assays$RNA@counts
#rownames(lihc)
#colnames(lihc)
#all.equal(lihc_metadat$cell_id,colnames(lihc))

#saveRDS(lihc,"/N/project/degas_st/CosMx_liver_data/lihc_dat.rds")
lihc = readRDS("/N/project/degas_st/CosMx_liver_data/lihc_dat.rds")
# Defining final matrices for training
feats1 = intersect(rownames(Xpat_t),rownames(lihc))
#saveRDS(feats1,"/N/project/degas_st/cosmyx/lihc_output_Nov14/feats1.rds")
#feats1 = readRDS("/N/project/degas_st/cosmyx/lihc_output_Nov14/feats1.rds")
stDat = lihc[feats1,]
rownames(stDat) <- colnames(lihc)
library(progress)

preprocessCounts <- function(X) {
  n <- nrow(X)
  pb <- progress_bar$new(format = "Normalizing [:bar] :percent", total = n, width = 60)
  
  out <- matrix(NA, nrow = n, ncol = ncol(X))
  for (i in seq_len(n)) {
    out[i, ] <- 1.5 ^ log2(X[i, ] + 1)
    pb$tick()
  }
  
  normalizeScale(out)
}

stDat = preprocessCounts(as.matrix(stDat))
stDat = as.matrix(stDat)

saveRDS(stDat,"/N/project/degas_st/cosmyx/lihc_output_Nov14_runDEGASatlas/stDat_Nov17.RDS")

#saveRDS(stDat,"/N/project/degas_st/cosmyx/lihc_output_Nov14_runDEGASatlas/stDat_Nov15.RDS")
#stDat = readRDS("/N/project/degas_st/cosmyx/lihc_output_Nov14_runDEGASatlas/stDat_Nov17.RDS")
dim(stDat)
patDat = Xpat_t[feats1,]

# Ensure genes column is character and numeric columns are numeric
patDat$genes <- as.character(patDat$genes)

# Convert all other columns to numeric (in case they were read as characters)
for (col in colnames(patDat)[-1]) {
  patDat[[col]] <- as.numeric(patDat[[col]])
}

# Check structure
str(patDat[1:5, 1:5])
patDat <- patDat[,-1]

patDat = preprocessCounts(as.matrix(patDat))
colnames(patDat) = Xpat_t[feats1,]$genes
rownames(patDat) = colnames(Xpat_t[feats1,-1])
colnames(stDat) = rownames(lihc[feats1,])

patLab = as.matrix(Ypat[which(Ypat$PATIENT_ID%in%intersect(Ypat$PATIENT_ID,rownames(patDat))),])
# If patLab is currently a matrix (which it looks like), first convert to data.frame
patLab <- as.data.frame(patLab, stringsAsFactors = FALSE)

# Make PATIENT_ID a character
patLab$PATIENT_ID <- as.character(patLab$PATIENT_ID)

# Make OS_time numeric
patLab$OS_time <- as.numeric(patLab$OS_time)

# Make OS_status numeric
patLab$OS_status <- as.numeric(patLab$OS_status)
head(patLab)


path.result = '/N/project/degas_st/cosmyx/lihc_output_Nov14_runDEGASatlas/'
tmpDir = paste0(path.result, 'tmp3/')
#dir.create(tmpDir) #if it doesn't exist already

#write.table(stDat,file=paste0(tmpDir, 'scExp.csv'), row.names=FALSE, sep=',')
#write.table(patDat,file=paste0(tmpDir, 'patExp.csv'), row.names=FALSE, sep=',')
#write.table(patLab,file=paste0(tmpDir, 'patLab.csv'), row.names=FALSE, sep=',')

library(dplyr)
 # Find intersecting genes for feature selection
intersecting_genes <-
  intersect(rownames(as.matrix(lihc)), colnames(as.matrix(patDat)))

# Feature selection (top 200 most variable genes)
#genes <- patDat %>% select(all_of(intersecting_genes)) %>% apply(2, var) %>% sort(decreasing=TRUE) %>% names() %>% head(200)
 
# patDat: your data frame
# intersecting_genes: vector of gene column names

# 1. Subset to intersecting genes
sub_mat <- patDat[ , intersecting_genes, drop = FALSE]

# 2. Compute variance for each gene (column)
vars <- apply(sub_mat, 2, var)

# 3. Sort variances decreasing
vars_sorted <- sort(vars, decreasing = TRUE)

# 4. Take the top 200 gene names
#genes <- names(vars_sorted)[1:200]
genes <- names(vars_sorted)[1:200]

stDat_df <- as.data.frame(stDat)
scExp <- stDat_df %>% select(all_of(genes))
patDat_df <- as.data.frame(patDat)
patExp <- patDat_df %>% select(all_of(genes))
#patLab
dim(stDat)
dim(patDat)
dim(patLab)


Nsubsample = 20000
folds = splitKfoldCV(dim(stDat)[1],floor(dim(stDat)[1]/Nsubsample))
# Training DEGAS model

 model1 = runDEGASatlas(stDat,NULL,patDat,patLab,tmpDir,"BlankClass","DenseNet",3,5,20000,123)
saveRDS(model1,file="/Users/dchatter/Documents/DEGAS_Bioinformatics_revision1/model1_t2d.rds")











### save as csv
combined_lihc <- cbind(lihc_metadat,scExp)
str(lihc_metadat)
str(combined_lihc)

write.csv(combined_lihc,"/N/project/degas_st/cosmyx/lihc_output_Nov14/combined_lihc_metadat.csv")

stDat <- combined_lihc
str(stDat)
stDat %>% select(all_of(genes))
                             
      fov = stDat$fov
      coord1 = stDat$x_slide_mm
      coord2 = stDat$y_slide_mm
      x_FOV_px = stDat$x_FOV_px
      y_FOV_px = stDat$y_FOV_px
      sample = stDat$slide_ID_numeric
      cellType = stDat$cellType
      niche = stDat$niche






# Initialize function to run DEGAS iteratively across increasing number of feature sets.
runDEGASBlankCox <- function(stDat, patDat, patLab, genes, iter) {
  
  path.data = '/N/project/degas_st/cosmyx/data/DEGAS/'
  path.result = '/N/project/degas_st/cosmyx/lihc_output_Nov14/'
  initDEGAS()
  DEGAS.toolsPath <<- '/N/project/degas_st/DEGAS_package/DEGAS/tools/'
  # overwrite the DEGAS path with your python location (module load deeplearning/2.9.1)
  DEGAS.pyloc <<- '/N/soft/rhel8/deeplearning/Python-3.10.10/bin/python3.10'
  tmpDir = paste0(path.result, 'tmp/')
  #DEGAS.seed <<- 100

  #/N/soft/rhel8/python/gnu/3.10.5/lib/python3.10/site-packages/tensorflow/__init__.py
  #/N/soft/rhel8/deeplearning/Python-3.10.10/bin/python3.10
  #/geode2/soft/hps/rhel7/deeplearning/Python-3.10.5/bin/python3.10
  #path.data = ''
  #path.result = ''
  #initDEGAS()
  #tmpDir = paste0(path.result, 'tmp/')

  set_seed_term(2)
  ccoxModel_PRAD =
    runCCMTLBag(
      scExp = stDat %>% select(all_of(genes)),
      scLab = NULL, #stLab %>% pull(cluster) %>% toOneHot(),
      patExp = patDat %>% select(all_of(genes)),
      patLab = patLab %>% select(OS_time, OS_status) %>% apply(2, as.numeric),
      tmpDir = tmpDir,
      'BlankCox','DenseNet',3,5)

  saveRDS(ccoxModel_PRAD, file = paste0('/N/project/degas_st/cosmyx/lihc_output_Nov14/',sample_name, "_",iter, "_",  Sys.Date(), '.RDS'))

  model_output <-
    tibble(
      as_tibble(predClassBag(ccoxModel_PRAD,
                             stDat %>% select(all_of(genes)),
                             'pat')),
                             #cell_id = ,
      fov = stDat$FOV,
      coord1 = stDat$x_slide_mm,
      coord2 = stDat$y_slide_mm,
      sample = stDat$slide_ID_numeric,
      cellType = stDat$cellType,
      niche = stDat$niche)

  colnames(model_output)[1] <- "Hazard"

  model_output %<>% mutate(Haz_scaled = (Hazard - min(Hazard)) / max(Hazard), .before = 'Hazard')

  return(model_output)
}

i=length(genes)
#for (i in c(10, 20, 40, 80, 120, 160, 200)) {

  output <-
    runDEGASBlankCox(stDat = scExp,
                     patDat = patExp,
                     patLab = patLab,
                     genes = genes[1:i],
                     iter = i)
  iter=i

  med <- output %>% pull(Hazard) %>% median

  write_csv(output, file = paste0('/N/project/degas_st/cosmyx/lihc_output_Nov14/',sample_name,"_",Sys.Date(), '.csv'))
#}

 output <-
    runDEGASBlankCox(stDat = stDat_df,
                     patDat = patExp,
                     patLab = patLab,
                     genes = genes[1:i],
                     iter = i)
  iter=i

  med <- output %>% pull(Hazard) %>% median




