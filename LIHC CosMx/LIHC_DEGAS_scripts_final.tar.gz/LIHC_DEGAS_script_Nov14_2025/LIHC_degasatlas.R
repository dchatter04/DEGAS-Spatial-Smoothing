# In vscode, open a terminal, and type the following bash commands:

# srun -p gpu-debug -A r00257 --time=01:00:00 --gpus-per-node v100:1 --mem 100G --pty bash
# srun -p gpu -A r00257 --time=02:00:00 --gpus-per-node v100:1 --mem 50G --pty bash
# srun -p general -A r00257 --time=02:00:00 --mem 50G --pty bash
# srun -p gpu -A r00257 --time=02:00:00 -gpus-per-node v100:1 --mem 100G --pty bash

# module load r/4.2.1
# module load python/gpu/3.10.10
# R


library(devtools)
library(withr)
library(rprojroot)
library(tidyverse)
library(magrittr)
library(here)
# If DEGAS hasn't been installed, do so using this command (after creating a r-packages file in your root directory)
#with_libpaths(new = '~/r-packages', install_github("tsteelejohnson91/DEGAS"))
library(DEGAS)
library(DEGAS, lib.loc = "/N/project/degas_st/DEGAS_package")

set.seed(2)

meta_data_columns <- c("V1", "cell_id", "slide_ID_numeric", "Run_Tissue_name", "x_FOV_px", "y_FOV_px", "qcFlagsFOV", "cellType", "niche")

# What is the name of this experiment/sample?
sample_name <- "liver_coxmyx"

# Patient data
## RNA-seq
Xpat <- data.table::fread('/N/project/degas_st/cosmyx/data/TCGA/patDat.csv', sep = ",") # Tumor and normal tissue
Xpat_t <- as.data.frame(t(Xpat))
colnames(Xpat_t) = Xpat_t[1,]
Xpat_t <- Xpat_t[-1,]
Xpat_t$genes <- rownames(Xpat_t)
Xpat_t <- Xpat_t[,c(dim(Xpat_t)[2],1:(dim(Xpat_t)[2]-1))]
Xpat_t[1:5,1:5]

## Clinical outcomes
Ypat <- data.table::fread('/N/project/degas_st/cosmyx/data/Reference_liver/patLab.csv', sep = ",")
#Ypat = Ypat[colnames(Xpat),]
rownames(Ypat) = Ypat$PATIENT_ID


lihc_metadat = read_csv('/N/project/degas_st/CosMx_liver_data/cosmx_liver_metadata.csv') 
#View(lihc_metadat)
# Loading Xenium data
lihc_dat = readRDS("/N/project/degas_st/CosMx_liver_data/LiverDataReleaseSeurat_newUMAP.RDS")

lihc = lihc_dat@assays$RNA@counts
rownames(lihc)
colnames(lihc)


# Defining final matrices for training
feats1 = intersect(rownames(Xpat_t),rownames(lihc))
stDat = lihc[feats1,]

library(progress)

preprocessCounts <- function(X) {
  n <- nrow(X)
  pb <- progress_bar$new(format = "Normalizing [:bar] :percent", total = n, width = 60)
  
  out <- matrix(NA, nrow = n, ncol = ncol(X))
  for (i in seq_len(n)) {
    out[i, ] <- 1.5 ^ log2(X[i, ] + 1)
    pb$tick()
  }
  
  normalizeScale(out)
}

stDat = preprocessCounts(as.matrix(stDat))
stDat = as.matrix(stDat)

#saveRDS(stDat,"/N/project/degas_st/cosmyx/lihc_output_Nov14_runDEGASatlas/stDat_Nov15.RDS")


patDat = Xpat_t[feats1,]

# Ensure genes column is character and numeric columns are numeric
patDat$genes <- as.character(patDat$genes)

# Convert all other columns to numeric (in case they were read as characters)
for (col in colnames(patDat)[-1]) {
  patDat[[col]] <- as.numeric(patDat[[col]])
}

# Check structure
str(patDat[1:5, 1:5])
patDat <- patDat[,-1]

patDat = preprocessCounts(as.matrix(patDat))
patLab = as.matrix(Ypat[rownames(patDat),-1])
colnames(patDat) = Xpat_t[feats1,]$genes
rownames(patDat) = colnames(Xpat_t[feats1,-1])
colnames(stDat) = rownames(lihc[feats1,])

path.result = '/N/project/degas_st/cosmyx/lihc_output_Nov14_runDEGASatlas/'
tmpDir = paste0(path.result, 'tmp/')
#dir.create(tmp) #if it doesn't exist already

#write.table(stDat,file=paste0(tmpDir, 'scExp.csv'), row.names=FALSE, sep=',')
#write.table(patDat,file=paste0(tmpDir, 'patExp.csv'), row.names=FALSE, sep=',')
#write.table(patLab,file=paste0(tmpDir, 'patLab.csv'), row.names=FALSE, sep=',')

intersecting_genes <-
  intersect(colnames(stDat), colnames(patDat))

# Feature selection (top 200 most variable genes)
genes <- as.data.frame(patDat) %>% select(all_of(intersecting_genes)) %>% apply(2, var) %>% sort(decreasing=TRUE) %>% names() %>% head(200)
 
 #library(dplyr)

# stDat_df <- as.data.frame(stDat)
# scExp <- stDat_df %>% select(all_of(genes))
# patDat_df <- as.data.frame(patDat)
# patExp <- patDat_df %>% select(all_of(genes))


########## new DEGAS----

initDEGAS <- function(){
  #DEGAS.pyloc <<- "python3"
  #DEGAS.toolsPath <<- paste0(.libPaths()[1],"/DEGAS/tools/")
  DEGAS.pyloc <<- '/N/soft/rhel8/deeplearning/Python-3.10.10/bin/python3.10'
 DEGAS.toolsPath <<- '/N/project/degas_st/DEGAS_package/DEGAS/tools/'
  # overwrite the DEGAS path with your python location (module load deeplearning/2.9.1)
  DEGAS.train_steps <<- 2000
  DEGAS.scbatch_sz <<- 200
  DEGAS.patbatch_sz <<- 50
  DEGAS.hidden_feats <<- 50
  DEGAS.do_prc <<- 0.5
  DEGAS.lambda1 <<- 3.0
  DEGAS.lambda2 <<- 3.0
  DEGAS.lambda3 <<- 3.0
  DEGAS.seed <<- "NULL"
}


runDEGASatlas <- function(scDat,scLab,patDat,patLab,tmpDir,model_type,architecture,FFdepth,Bagdepth,Nsubsample,seed){
  folds = splitKfoldCV(dim(scDat)[1],floor(dim(scDat)[1]/Nsubsample))
    initDEGAS <- function(){
  DEGAS.pyloc <<- '/N/soft/rhel8/deeplearning/Python-3.10.10/bin/python3.10'
  DEGAS.toolsPath <<- '/N/project/degas_st/DEGAS_package/DEGAS/tools/'
  # overwrite the DEGAS path with your python location (module load deeplearning/2.9.1)
  DEGAS.train_steps <<- 2000
  DEGAS.scbatch_sz <<- 200
  DEGAS.patbatch_sz <<- 50
  DEGAS.hidden_feats <<- 50
  DEGAS.do_prc <<- 0.5
  DEGAS.lambda1 <<- 3.0
  DEGAS.lambda2 <<- 3.0
  DEGAS.lambda3 <<- 3.0
  DEGAS.seed <<- "NULL"
}
  initDEGAS()
  ccModel_out = list()
  for (f in folds){
  
    set_seed_term(2)
    ccModel_tmp = runCCMTLBag(scDat[f,],scLab[f,],patDat,patLab,tmpDir,model_type,architecture,FFdepth,Bagdepth)
    ccModel_out = c(ccModel_out,ccModel_tmp)
  }
  return(ccModel_out)
}


# Training DEGAS model
#tmpDir = '/N/project/degas_st/cosmyx/lihc_output_Nov14_runDEGASatlas/tmp/'
model1 = runDEGASatlas(stDat,NULL,patDat,patLab,tmpDir,"BlankCox","DenseNet",3,5,20000,123)
  #model1 = runDEGASatlas(scExp,NULL,patExp,patLab,tmpDir,"BlankCox","DenseNet",3,5,20000,123)
 
   saveRDS(model1,file="/N/project/degas_st/cosmyx/lihc_output_Nov14/runDEGASatlas_model1_Nov14.rds")
  #preds = predClassBag(model1,scExp,"pat")
  #saveRDS(preds,file="/N/project/degas_st/cosmyx/lihc_output_Nov14/runDEGASatlas_preds1_Nov14.rds")

