#!/bin/bash

#SBATCH -J cosmx
#SBATCH -p gpu
#SBATCH -A r00257
#SBATCH -o log/AD_cosmx_%j.txt
#SBATCH -e log/AD_cosmx_%j.err
#SBATCH --mail-type=ALL
#SBATCH --mail-user=jcouetil@iu.edu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=10
#SBATCH --gpus-per-node v100:1
#SBATCH --time=5:00:00
#SBATCH --mem=50G


module load r/4.2.1
module load python/gpu/3.10.10

# Rscript /N/project/degas_st/cosmyx/AD_cosmyx_DEGAS.R
Rscript /N/project/degas_st/cosmyx/liver_cosmyx_DEGAS.R


