#!/bin/bash

#SBATCH -J cosmx
#SBATCH -p gpu
#SBATCH -A r00257
#SBATCH -o log/LIHC_cosmx_%j.txt
#SBATCH -e log/LIHC_cosmx_%j.err
#SBATCH --mail-type=ALL
#SBATCH --mail-user=dchatter@iu.edu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=10
#SBATCH --gpus-per-node v100:1
#SBATCH --time=5:00:00
#SBATCH --mem=200G


module load r/4.4.1
module load python/gpu/3.10.10

# Rscript /N/project/degas_st/cosmyx/AD_cosmyx_DEGAS.R
Rscript /N/project/degas_st/cosmyx/LIHC_DEGAS_script_Nov14_2025/LIHC_DEGAS_old.R
