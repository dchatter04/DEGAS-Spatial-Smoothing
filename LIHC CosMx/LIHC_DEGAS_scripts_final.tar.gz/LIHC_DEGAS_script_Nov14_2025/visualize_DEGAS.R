# module load r/4.2.1

library(tidyverse)

output_dir = '/N/project/degas_st/cosmyx/degas_output'

to_read = list.files(output_dir)

# liver_coxmyx_tumor_only
# liver
# to_read = to_read[str_detect(to_read, "AD*.csv")]
to_read = to_read[str_detect(to_read, "liver_coxmyx_tumor_only")]

output_list = map(to_read, function(x) data.table::fread(file = file.path(output_dir, x)))

combined_data = data.table::rbindlist(output_list)
#combined_data

summarized_data <- combined_data %>%
    group_by(fov, coord1, coord2, sample) %>%
    # mean of V1 and mean of V2
    rename(AD = V1, NORM = V2) %>%
    # just calculate mean_AD, and then replace all mean_hazard below with mean_AD
    summarize(mean_AD = mean(AD, na.rm = TRUE))

summarized_data %>%
    sample_frac(0.2) %>%
    ggplot(aes(x = coord1, y = coord2, color = mean_hazard)) +
    theme_void() +
    geom_point(size = 0.02) +
    facet_wrap(~sample) +
    coord_fixed() +
    scale_color_gradient2(low='blue', mid = 'white', high = 'red')
    
filtered_data %>%
    ggplot(aes(x = coord1, y = coord2, color = mean_hazard)) +
    theme_void() +
    geom_point(size = 0.02) +
    facet_wrap(~sample) +
    coord_fixed() +
    scale_color_gradient2(low='blue', mid = 'white', high = 'red')
    

summarized_data %>%
    ggplot(aes(x = coord1, y = coord2)) +
    theme_void() +
    geom_point(size = 0.02) +
    facet_wrap(~sample) +
    coord_fixed() +
    scale_color_gradient2(low='blue', mid = 'white', high = 'red')
    

# Visaulize FOVs

met <- read_csv('/N/project/degas_st/CosMx_liver_data/cosmx_liver_metadata.csv')
met <- read_csv('/N/project/degas_st/cosmyx/AD_final_metadata.csv')

met %>% select(contains("mm"), contains("px"), cell_id)

meta_df <- met %>%
    # select(contains("mm"), contains("px"), cell_id, slide_ID_numeric, cellType) %>%
    mutate(fov = str_replace(str_replace(cell_id, "c_[:digit:]_", ""), "_[:digit:].*$", ""), .before = cell_id) %>%
    transmute(
        x_slide_mm, y_slide_mm, 
        fov = as.numeric(fov),
        sample = slide_ID_numeric,
        coord1 = x_FOV_px,
        coord2 = y_FOV_px,
        cellType)


# Plotting the Hazard
comb_meta_df <- meta_df %>% inner_join(combined_data)

comb_meta_df <- comb_meta_df %>%
    mutate(Haz_scaled = Haz_scaled - median(Haz_scaled, na.rm = TRUE))

comb_meta_df %>% head()

ggplot(
    comb_meta_df %>% sample_frac(0.01), 
    aes(x = x_slide_mm, y = y_slide_mm, color = Haz_scaled)) +
    geom_point(size = 0.2) +
    theme_void() +
    scale_color_gradient2(low = 'green', mid = 'white', high = 'red') +
    facet_wrap(~sample)

#print this
ggplot(
    comb_meta_df %>% group_by(fov) %>% summarize(x_slide_mm, y_slide_mm, sample, Haz_scaled = mean(Haz_scaled)) %>% unique(), 
    aes(x = x_slide_mm, y = y_slide_mm, color = Haz_scaled)) +
    geom_point(size = 0.2) +
    theme_void() +
    scale_color_gradient2(low = 'yellow', mid = 'white', high = 'red') +
    facet_wrap(~sample)


rounded_df <- comb_meta_df %>%
        mutate(
            x_slide_mm = round(x_slide_mm, 1),
            y_slide_mm = round(y_slide_mm, 1), 
            sample) %>%
        group_by(x_slide_mm, y_slide_mm) %>%
        summarize(
            x_slide_mm, y_slide_mm, 
            sample, 
            Haz_scaled = mean(Haz_scaled)) %>% unique()

cell_type_df <- comb_meta_df %>%
    # head(1000) %>%
    mutate(
        x_slide_mm = round(x_slide_mm, 1),
        y_slide_mm = round(y_slide_mm, 1)) %>%
    group_by(sample, x_slide_mm, y_slide_mm, cellType) %>%
    summarize(count = n(), .groups = "drop")#  %>%
    # pivot_wider(names_from = cellType, values_from = count, values_fill = list(count = 0)) 
    

#print this

allcellsplot <- cell_type_df %>%
    group_by(cellType) %>%
    mutate(count = (count-min(count))/(max(count)-min(count))) %>%
    ggplot(aes(x = x_slide_mm, y = y_slide_mm, color = count)) +
    geom_point(size = 0.2, shape = 15) +
    facet_wrap(sample~cellType)+
    theme_void() +
    scale_color_viridis_c(option = 'plasma')+
    coord_fixed()

allcellsplot

# Mean hazard of a neighborhood of cells

mean_mean_hazard <- mean(rounded_df$Haz_scaled)
stand_dev <- sd(rounded_df$Haz_scaled)*3

filtered_data <- rounded_df %>%
    # filter out observations that are more than 3SD above/below
    filter((Haz_scaled < mean_mean_hazard + stand_dev) & (Haz_scaled > mean_mean_hazard - stand_dev))

riskplot <- ggplot(filtered_data, 
    aes(x = x_slide_mm, y = y_slide_mm, color = Haz_scaled)) +
    geom_point(size = 2, shape = 15) +
    theme_void() +
    coord_fixed() +
    #scale_color_gradient2(low = 'blue', mid = 'yellow', high = 'red', limits = c(min(rounded_df$Haz_scaled), max(rounded_df$Haz_scaled))) +
     scale_color_gradient2(low = "blue", mid = "white", high = "red") +
    facet_wrap(~sample)


# Hazard by cell type per sample
plot_object <- comb_meta_df %>%
    group_by(sample, cellType) %>%
    summarize(
        mean_hazard = mean(Haz_scaled),
        sd_hazard = sd(Haz_scaled)) %>%
        ggplot(aes(x = cellType, y = mean_hazard)) +
        geom_col() +
        facet_wrap(~sample) +
        theme_classic() +
        coord_flip()+
        theme(
    axis.text.x = element_text(size = 12, color = "black",face = "bold"),  # Adjust size and color for x-axis text
    axis.text.y = element_text(size = 12, color = "black",face = "bold"),  # Adjust size and color for y-axis text
    plot.title = element_text(size = 14, color = "black",face = "bold"),    # Adjust size and color for plot title
    strip.text = element_text(size = 12, color = "black", face = "bold") 
  )
plot_object


directory_path <- "/N/u/dchatter/Quartz/thindrives/OneDrive-IndianaUniversity/DEGAS/CosMx liver data"
#file_name <- "hazard_by_celltype.png"
#file_name <- "allcellsplot.png"
file_name <- "riskplot.png"
file_path <- file.path(directory_path, file_name)
ggsave(file_path, plot = riskplot, width = 12, height = 6,dpi=300,limitsize=FALSE)
ggsave("allcellplot.pdf", plot = allcellsplot, device = "pdf", width = 8, height = 6)
inner_join(cell_type_df, rounded_df)

